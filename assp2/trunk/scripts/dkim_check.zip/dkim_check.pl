#!/usr/local/bin/perl


use Mail::DKIM::DkimPolicy;

  my $policy = Mail::DKIM::DkimPolicy->fetch(
            Protocol => "dns",
            Author => 'jsmith@example.org',
          );



