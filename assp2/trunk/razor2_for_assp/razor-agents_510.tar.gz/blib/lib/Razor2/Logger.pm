# $Id: Logger.pm,v 1.22 2005/06/10 18:31:32 vipul Exp $ 

package Razor2::Logger;

use strict;
use IO::File;
use Time::HiRes qw(gettimeofday);
use POSIX qw(strftime);

sub new { 

    my ($class, %args) = @_;
    my %self = ( %args );
    my $self = bless \%self, $class;

    $self->{LogDebugLevel} = exists $self->{LogDebugLevel} ? $self->{LogDebugLevel} : 5;

    eval{&main::mlog(0,'');};
    unless ($@) {
        return $self;
    }
    
    if ($self->{LogTo} =~ /^file:(.*)$/) {
        $self->{LogType} = 'file';
        my $name = $1; chomp $name;
        open (LOGF, ">>$name") or do {
            open LOGF, ">>/dev/null" or do {
                print STDERR "Failed to open /dev/null, $!\n";
            };
        };
        LOGF->autoflush(1);
        $self->{fd} = *LOGF{IO};
    } elsif ($self->{LogTo} eq 'stdout') {
        $self->{LogType} = 'file';
        $self->{fd} = *STDOUT{IO};
    } elsif ($self->{LogTo} eq 'stderr') {
        $self->{LogType} = 'file';
        $self->{fd} = *STDERR{IO};
    } else {
        $self->{LogType} = 'file';
        $self->{fd} = *STDERR{IO};
    }

    $self->{LogTimeFormat} ||= "%b %d %H:%M:%S";  # formatting from strftime()
    $self->{LogDebugLevel}   = exists $self->{LogDebugLevel} ? $self->{LogDebugLevel} : 5;
    $self->{Log2FileDir}   ||= "/tmp";

    $self->log(2,"[bootup] Logging initiated LogDebugLevel=$self->{LogDebugLevel} to $self->{LogTo}");

    return $self;

}


sub log { 

    my ($self, $prio, $message) = @_;

    return unless $prio <= $self->{LogDebugLevel};

    if ($self->{asspLog}) {
        &main::mlog($self->{asspLog},"razor message [$self->{LogPrefix}]: $message",1,1);
    } elsif ($self->{LogType} eq 'file') {
        my $now_string;
        if ($self->{LogTimestamp}) {
            my ($seconds, $microseconds) = gettimeofday;
            $now_string = strftime $self->{LogTimeFormat}, localtime($seconds);
            $now_string .= sprintf ".%06d ", $microseconds;
        }

        my $logstr = sprintf("%s[%d]: [%2d] %s\n", $self->{LogPrefix}, $$, $prio, $message);
        $logstr =~ s/\n+\n$/\n/;
        my $fd = $self->{fd};
        print $fd "$now_string$logstr";
    }

    return 1;
} 

sub log2file {
    my ($self, $prio, $textref, $fn_ext) = @_;

    return unless $prio <= $self->{LogDebugLevel};

    unless (ref($textref) eq 'SCALAR') {
        print "log2file: not a scalar ref ($fn_ext)\n";
        return;
    }
    my $len = length($$textref);
    my $fn = "$self->{Log2FileDir}/razor.$$.$fn_ext";

    if (open OUT, ">$fn") {
        print OUT $$textref;
        close OUT;
        $self->log($prio,"log2file: wrote message len=$len to file: $fn");
    } else {
        $self->log($prio,"log2file: could not write to $fn: $!");
    }
    return;
}

1;

