#!/usr/local/bin/perl

# mod_inst.pl

# Installs Perl modules used by ASSP an needed Software - tesseract / ImageMagick

# http://assp.sourceforge.net/

use strict;

use warnings;
use File::Copy;
use Config;
use 5.012;

our $forceCPAN;
our $is_x86_64;
BEGIN {
    $forceCPAN = $Config::Config{'uname'} =~ /strawberry-perl/o || $Config::Config{'myuname'} =~ /strawberry-perl/o;
    $is_x86_64 = 1 if ($forceCPAN && ($Config::Config{'uname'} =~ /x64/o || $Config::Config{'myuname'} =~ /x64/o))
}
no Config;

my $myversion = '2.10';   # 2021.12.10 Thomas Eckardt

###########################################
# please change the following to your needs
#
# uncomment and change the following line(s) if you use a HTTP-Proxy and ENV is not set
#$ENV{HTTP_proxy} = 'http://yourproxy:port';
#$ENV{HTTP_proxy_user} = 'proxy-user';
#$ENV{HTTP_proxy_pass} = 'proxy-user-password';
###########################################

print "Perl " . $] . "  ASSP2 module installation helper version $myversion\n\n";

die "At least Perl version 5.012000 (5.12.0) is required to run ASSP (5.012003 / 5.12.3 is at least recommended) - you are running Perl version $] - please upgrade Perl first!\n" if($] lt '5.012000');
if($] lt '5.012003') {
    print "Perl version 5.013003 (5.12.3) is at least recommended to run ASSP - you are running Perl version $] - please upgrade Perl first!\n\n";
    print "press ENTER to continue - press CTRL C to stop\n";
    <STDIN>;
}

my $cmd;
our %ConfigASSP;
our $asspdir;
my $perl;
my $perlbindir;
my $perldosbindir;
our $OCR;


if ( $ARGV[0] ) {
    $asspdir = $ARGV[0];
} else {
    if ($^O ne "MSWin32") {
        foreach ( '../..','.','assp', '/usr/local/assp', '/home/assp','/etc/assp', '/usr/assp', '/applications/assp', '/assp', '/opt/assp') {
            if (-e "$_/assp.cfg") {
                $asspdir = $_;
                last;
            }
        }
    }
}
if ( ($ARGV[1] && $ARGV[1] =~ /-{0,2}OCR/io) || $0 =~ /ocr/io) {
    $OCR = 1;
    print "will install binaries and perl modules required for the ASSP_OCR Plugin\n",
}

# get / set assp-install-dir and proxy
if ($^O eq "MSWin32") {
    $perl = $^X;
    ($perldosbindir) = $perl =~ /^(\S:\\.*)\\[^\\]+$/;
    $perldosbindir =~ s/\\/\\\\/g;
    $perl =~ s/\\/\//g;
    ($perlbindir) = $perl =~ /^(\S:\/.*)\/[^\/]+$/;
    $perlbindir =~ s/\/bin$/\/site\/bin/;

    if (! $asspdir) {
        $cmd = 'DIR';
        my $out = `$cmd`;
        ($asspdir) = $out =~ /(\S:\\.*)\\[^\\]+\\[^\\]+/;
    }

    $asspdir = "..\\.." unless $asspdir;
    if (! -e $asspdir."\\assp.cfg" && -e $asspdir."\\assp.cfg.new_install") {
        rename($asspdir."\\assp.cfg.new_install",$asspdir."\\assp.cfg");
    }
    if (! $asspdir || ! -e $asspdir."\\assp.cfg") {
        $asspdir = "..\\.." unless $asspdir;
        die "$asspdir\\assp.cfg not found!\nASSP has to be installed and configured (proxyserver) before running this script!\nThis script has to run in the [ASSP_install_DIR]/assp.mod/install directory!\nFor example C:\\assp\\assp.mod\\install\nOr call \>perl modinst.pl [Full_Path_To_ASSP_Install_DIR]\nPlease correct this!\n";
    }

    if (-e "$asspdir\\assp.cfg") {
        print "reading proxy settings from assp.cfg\n";
        open(CFG,"<$asspdir\\assp.cfg"); local $/; (%ConfigASSP)=split(/:=|\n/,<CFG>); close CFG;
        $ENV{HTTP_proxy} = $ConfigASSP{proxyserver} if ($ConfigASSP{proxyserver} && ! $ENV{HTTP_proxy});
    } else {
        if ($^O eq "MSWin32" && ! $ENV{HTTP_proxy}) {
            my $rkey;
            my $Registry;
            print "reading IE proxy settings from windows-registry\n";
            eval("use Win32::TieRegistry ( Delimiter=>'/', ArrayValues=>1 );");
            $rkey=$Registry->{'CUser/Software/Microsoft/Windows/CurrentVersion/Internet Settings'};
            if (unpack("N", pack("H8", substr($rkey->GetValue( "ProxyEnable" ), -8)))) {
                $ENV{HTTP_proxy} = $rkey->GetValue( "ProxyServer" );
            }
        }
    }
} else {
    $asspdir = "../.." unless $asspdir;
    if (! -e "$asspdir/assp.cfg" && -e "$asspdir/assp.cfg.new_install") {
        rename($asspdir."\\assp.cfg.new_install",$asspdir."\\assp.cfg");
    }
    if (! -e "$asspdir/assp.cfg") {
        die "$asspdir/assp.cfg not found!\nASSP has to be installed and configured (proxyserver) before running this script!\nThis script has to run in the [ASSP_install_DIR]/assp.mod/install directory!\nFor example /opt/assp/assp.mod/install\nOr call \>perl modinst.pl [Full_Path_To_ASSP_Install_DIR]\nPlease correct this!\n";
    } else {
        print "reading proxy settings from assp.cfg\n";
        open(CFG,"<$asspdir/assp.cfg"); local $/; (%ConfigASSP)=split(/:=|\n/,<CFG>); close CFG;
        $ENV{HTTP_proxy} = $ConfigASSP{proxyserver} if ($ConfigASSP{proxyserver} && ! $ENV{HTTP_proxy});
    }
}

unshift @INC , "$asspdir/lib";

$cmd = "openssl version";
my $OK = `$cmd`;

print "got answer '$OK' from OpenSSL - assume OpenSSL is already installed\n" if ($OK =~ /OpenSSL\s+\d+\.\d+\.\d+/i);

if ($OK !~ /OpenSSL\s+\d+\.\d+\.\d+/i) {
    print "\nOpenSSL is required for ASSP - please install OpenSSL first\n\n";
    exit;
}

if ($ENV{HTTP_proxy}) {
    print "will make downloads via proxy $ENV{HTTP_proxy}\n";
} else {
    print "\%HTTP_proxy\% is not set - will make downloads via direct connect\n";
}

my $moddir = $asspdir.'\\assp.mod\\';
if ($^O eq "MSWin32") {
    print "copying needed binary files to $perlbindir\n";
    $cmd = "copy ".$asspdir."\\assp.mod\\bin\\*.* ".$perlbindir;
    $cmd =~ s/\//\\/go;
    print "$cmd\n";
    system($cmd);
    if (! $forceCPAN) {
        print "checking and adding PPM-repositories for module installation\n";
        $cmd = 'ppm rep';
        my $out = `$cmd`;
        if ($out !~ /trouchelle\.510/i && substr($],0,5) eq '5.010') {
            print "adding respository 'trouchelle.510' 'http://trouchelle.com/ppm10/' to ppm\n";
            $cmd = 'ppm rep add trouchelle.510 http://trouchelle.com/ppm10/';
            system($cmd);
        }
        if ($out !~ /trouchelle\.512/i && substr($],0,5) eq '5.012') {
            print "adding respository 'trouchelle.512' 'http://trouchelle.com/ppm12/' to ppm\n";
            $cmd = 'ppm rep add trouchelle.512 http://trouchelle.com/ppm12/';
            system($cmd);
        }
        if ($out !~ /trouchelle\.514/i && substr($],0,5) eq '5.014') {
            print "adding respository 'trouchelle.514' 'http://trouchelle.com/ppm14/' to ppm\n";
            $cmd = 'ppm rep add trouchelle.514 http://trouchelle.com/ppm14/';
            system($cmd);
        }
        if ($out !~ /trouch\-act/i && substr($],0,5) eq '5.010') {
            print "adding respository 'trouch-act' 'http://trouchelle.com/ppm10/activestate/1000/' to ppm\n";
            $cmd = 'ppm rep add trouch-act http://trouchelle.com/ppm10/activestate/1000/';
            system($cmd);
        }
        if ($out !~ /winnipeg\.510/i && substr($],0,5) eq '5.010') {
            print "adding respository 'uni_winnipeg.510' 'http://cpan.uwinnipeg.ca/PPMPackages/10xx/' to ppm\n";
            $cmd = 'ppm rep add uni_winnipeg.510 http://cpan.uwinnipeg.ca/PPMPackages/10xx/';
            system($cmd);
        }
        if ($out !~ /winnipeg\.512/i && substr($],0,5) eq '5.012') {
            print "adding respository 'uni_winnipeg.512' 'http://cpan.uwinnipeg.ca/PPMPackages/12xx/' to ppm\n";
            $cmd = 'ppm rep add uni_winnipeg.512 http://cpan.uwinnipeg.ca/PPMPackages/12xx/';
            system($cmd);
        }
        if ($out !~ /winnipeg\.514/i && substr($],0,5) eq '5.014') {
            print "adding respository 'uni_winnipeg.514' 'http://cpan.uwinnipeg.ca/PPMPackages/14xx/' to ppm\n";
            $cmd = 'ppm rep add uni_winnipeg.514 http://cpan.uwinnipeg.ca/PPMPackages/14xx/';
            system($cmd);
        }
        if ($out !~ /bribes/i) {
            print "adding respository 'bribes.org' 'http://www.bribes.org/perl/ppm/' to ppm\n";
            $cmd = 'ppm rep add bribes.org http://www.bribes.org/perl/ppm/';
            system($cmd);
        }
        if ($out !~ /assp2/i) {
            print "adding respository 'ASSP2' to ppm\n";
            $cmd = "ppm repo add ASSP2 \"http://downloads.sourceforge.net/project/assp/ASSP V2 multithreading/packages/\"";
            system($cmd);
        }
        if ($out !~ /assp[^2]?/i) {
            print "adding respository '$moddir' to ppm\n";
            $cmd = "ppm rep add $moddir";
            system($cmd);
        }
        $cmd = "ppm rep sync";
        system($cmd);
    }
}

my $ver = eval("use LWP::Simple; LWP::Simple->VERSION;");
print "\nerror calling required module LWP::Simple - $@\n" if $@;
if (! $ver) {
    print "================================\n";
    print "= Installing module LWP::Simple=\n";
    print "================================\n";
    my $cmd = "ppm install LWP-Simple";
    $cmd = "cpan LWP::Simple" if ($^O ne "MSWin32" || $forceCPAN);
    system($cmd);
    $ver = eval("use LWP::Simple; LWP::Simple->VERSION;");
    print "\nerror calling required module LWP::Simple - $@\n" if $@;
    if (! $ver) {
        print "\n\nmodule LWP::Simple is not installed or not working - please install this module manualy and try again - cancel installation\n\n";
        exit;
    }
}

$ver = eval("use LWP::Protocol::https; LWP::Protocol::https->VERSION;");
print "\nerror calling required module LWP::Protocol::https - $@\n" if $@;
if (! $ver) {
    print "=========================================\n";
    print "= Installing module LWP::Protocol::https=\n";
    print "=========================================\n";
    my $cmd = "ppm install LWP::Protocol::https";
    $cmd = "cpan -i -T LWP::Protocol::https" if ($^O ne "MSWin32" || $forceCPAN);
    system($cmd);
    $ver = eval("use LWP::Protocol::https; LWP::Protocol::https->VERSION;");
    print "\nerror calling required module LWP::Protocol::https - $@\n" if $@;
    if (! $ver) {
        print "\n\nmodule LWP::Protocol::https is not installed or not working - please install this module manualy and try again - cancel installation\n\n";
        exit;
    }
}

if ($^O eq "MSWin32") {
    my $list = get('https://downloads.sourceforge.net/project/assp/ASSP%20V2%20multithreading/autoupdate/version.txt');
    if (! $list) {
        print "\n\nthe script is unable to download https://downloads.sourceforge.net/project/assp/ASSP%20V2%20multithreading/autoupdate/version.txt\n";
        if ($ENV{HTTP_proxy}) {
            print "please check the internet connection and the Proxy-Option - edit install.cmd\n";
        } else {
            print "there is no Proxy configured - please check the internet connection and the Proxy-Option - edit install.cmd\n";
        }
        print "\ncancel installation\n\n";
        exit;
    }
}
if ($^O ne "MSWin32") {
    my $list = get('https://downloads.sourceforge.net/project/assp/ASSP%20V2%20multithreading/autoupdate/version.txt');
    if (! $list) {
        print "\n\nthe script is unable to download https://downloads.sourceforge.net/project/assp/ASSP%20V2%20multithreading/autoupdate/version.txt\n";
        if ($ENV{HTTP_proxy}) {
            print "please check the internet connection and the Proxy-Option\n";
        } else {
            print "there is no Proxy configured - please check the internet connection and the Proxy-Option\n";
        }
        print "\ncancel installation\n\n";
        exit;
    }
}

# array of required perl modules.

our @Modules;

if (($^O ne "MSWin32" || $forceCPAN) && ! eval{require App::cpanminus}) {
    push (@Modules, 'App::cpanminus/0');
}
if (($^O ne "MSWin32" || $forceCPAN) && ! eval{require App::cpanoutdated}) {
    push (@Modules, 'App::cpanoutdated/0');
}


if ($^O eq "MSWin32" && $OCR) {
    my (@tessfiles) = qw{
      http://downloads.sourceforge.net/project/assp/ASSP%20V2%20multithreading/ASSP%20V2%20module%20installation/tesseract4win/Tesseract-OCR.bin.tar.gz
      };

    my $out = `tesseract -v`;
    print "found tesseract.log created by tesseract.exe v2 - assume tesseract is already installed - skip tesseract installation\n" if (-e "tesseract.log");
    print "got answer from tesseract.exe v3 - assume tesseract is already installed - skip tesseract installation\n" if ($out =~ /tesseract\s*\d+\./ios);

    if (! -e "tesseract.log" && $out !~ /tesseract\s*\d+\./ios) {
        print "================================\n";

        print "= Installing tesseract binary files in to $perlbindir\n";

        print "================================\n\n";
        print "NOTICE: To get tesseract working, you need to download and to extract (in to $perlbindir) the required tesseract data files from\n\n";
        print "http://downloads.sourceforge.net/project/assp/ASSP V2 multithreading/ASSP V2 module installation/tesseract4win/Tesseract-OCR.data.tar.gz\n\n";
        print "manually after this installation process is finished!\npress ENTER to continue\n";
        <STDIN>;

        foreach my $url (@tessfiles) {
            print "download url $url - please wait ...\n";
            my ($file) = $url =~ /([^\/]+)$/;
            my ($tarfile) = $file =~ /(.*)\.gz$/;
            my $boxdir = $perlbindir."/training";
            if (is_success(getstore($url,$file))) {
                print "install $file to $perlbindir - please wait ...\n";
                $cmd = "gunzip -d -f -N -r $file";
                system($cmd);
                chdir $perlbindir;
                chdir $boxdir if ($file =~ /boxtiff/);
                $cmd = "$asspdir\\assp.mod\\install\\tar -xf $asspdir\\assp.mod\\install\\$tarfile";
                system($cmd);
                chdir "$asspdir\\assp.mod\\install";
                unlink $tarfile;
            } else {
                print "\nerror downloading $url - cancel installation";
                exit;
            }
        }

        print "finished tesseract installation\n\n";
    }
    unlink "tesseract.log";

    my (@imfiles) = qw{
      http://www.imagemagick.org/download/binaries
      };

    my $progfiles = $ENV{'ProgramFiles(x86)'} || $ENV{ProgramFiles};
    my $imcmd = " /DIR=\"$progfiles\\ImageMagick\" /GROUP=ImageMagick /NOICONS /SILENT /NORESTART ";

    my $convert = '"'.$progfiles."\\ImageMagick\\convert\" -version";
    my $OK = `$convert`;
    if ($OK !~ /ImageMagick/i) {
        $convert = 'convert -version';
        $OK = `$convert`;
    }
    
    print "got answer from ImageMagick convert.exe - assume ImageMagick is already installed - skip ImageMagick installation\n" if ($OK =~ /ImageMagick/i);

    if ($OK !~ /ImageMagick/i) {

        print "================================\n";

        print "= Installing ImageMagick in to ".$progfiles."\\ImageMagick\n";

        print "================================\n\n";

        foreach my $url (@imfiles) {
            print "reading files in url $url- please wait ...\n";
            my $list = get($url);
            my ($file) = $list =~ /(ImageMagick\-\d+\.\d+\.\d+\-\d+\-Q\d+-x86-dll\.exe)/i;
            if ($file) {
                $url .= "/$file";
                print "download file $file - please wait ...\n";
                if (is_success(getstore($url,$file))) {
                    print "install ImageMagick in to $progfiles\\ImageMagick from file $file - please wait ...\n";
                    $imcmd = $file.$imcmd;
                    system($imcmd);
                    unlink $file;
                } else {
                    print "\nerror downloading $url - cancel installation";
                    exit;
                }
            } else {
                print "\nerror unable to detect the installable ImageMagick file at $url - cancel installation";
                exit;
            }
        }

        print "finished ImageMagick installation\n\n";
    }
}

if (open(my $F, '<' ,"$moddir/install/module_list.txt")) {
  while (<$F>) {
      s/^\s+//o;
      s/\s*#.*$//o;
      s/\r|\n//go;
      push @Modules, $_ if $_;
  }
  close $F;
} else {
  push (@Modules, qw{

  Encode::Detect/1.01
  Encode::HanExtra/0
  Time::ParseDate/2013.1113/--force
  Time::CTime/0
  Time::DaysInMonth/0
  Time::JulianDay/0
  Time::Timezone/0
  Text::Glob/0
  Number::Compare/0
  Compress::Zlib/2.008
  IO::Wrap/2.110
  Convert::TNEF/0.17
  Digest::MD5/2.36
  Digest::SHA1/2.11
  Email::Send/2.192
  Email::MIME/1.442
  Email::Valid/0.176
  Email::Outlook::Message/0.919
  File::ReadBackwards/1.04
  File::Scan::ClamAV/1.8
  LWP::Simple/1.41
  MIME::Types/1.23
  Mail::DKIM::Verifier/0.30_1
  Mail::DKIM/0.32
  Error/0.17016
  NetAddr::IP/4.007
  Net::IP/1.26
  Mail::SPF/2.007/--force--nodep
  Mail::SRS/0.31
  Net::CIDR::Lite/0.20
  Net::DNS/0.61
  Net::IP::Match::Regexp/1.00
  Net::LDAP/0.33
  Net::SMTP/2.31
  Net::SenderBase/1.01
  Net::Syslog/0.03
  PerlIO::scalar/0.05
  threads/1.81
  threads::shared/1.33
  Thread::Queue/2.11
  Thread::State/0.09
  Tie::DBI/1.02
  Time::HiRes/1.9707
  Schedule::Cron/0.97--force
  Sys::MemInfo/0.91
  Sys::CpuAffinity/1.05
  IO::Socket::SSL/1.22
  BerkeleyDB/0.31
  Crypt::CBC/2.30
  Crypt::OpenSSL::AES/0.02
  Crypt::GOST/1.01
  Authen::SASL/2.1401
  Data::Dumper/2.125
  Devel::Peek/1.04
  Devel::Size/0.71
  Devel::InnerPackage/0.4
  Convert::Scalar/1.04
  Net::SMTP::SSL/1.01
  Socket6/0.22
  IO::Socket::IP/0.31
  Lingua::Stem::Snowball/0.952
  Lingua::Identify/0.29
  Lingua::StopWords/0.09
  Lingua::Stem/0.84
  MIME::Charset/1.00
  Crypt::SMIME/0.13
  Unicode::LineBreak/2012.06
  Text::Unidecode/0.04
  Regexp::Optimizer/0.23 
  OLE::Storage_Lite/0
  IO::Compress::Gzip/0
  IO::Compress::Bzip2/0
  IPC::Run/0
  Archive::Zip/0
  Archive::Tar/0
  Archive::Rar/0
  Archive::Extract/0
  File::Type/0
  IO::Compress::Base/0
  IO::Compress::Deflate/0
  IO::Compress::Lzma/0
  IO::Compress::RawDeflate/0
  IO::Compress::Xz/0
  IO::Compress::Zip/0

  DBD::File/0.35
  DBD::LDAP/0.09
  DBD::ODBC/1.15
  DBD::PgPP/0.05
  DBD::Sprite/0.59
  DBD::mysql/4.005

  Razor2::Client::Agent/0

  HTML::Strip/0
  HTML::TreeBuilder/0
  XML::RSS/0
  
  Alien::Libarchive/0.27
  Archive::Libarchive::XS/0.0901
  JSON/4.02
  });
}

if ($OCR && open(my $F, '<' ,"$moddir/install/module_list_ocr.txt")) {
  while (<$F>) {
      s/^\s+//o;
      s/\s*#.*$//o;
      s/\r|\n//go;
      push @Modules, $_ if $_;
  }
  close $F;
} elsif ($OCR) {
  push (@Modules, qw{
  YAML/0
  File::Find::Rule/0.30/--force--nodep
  File::Slurp/0/--force--nodep
  File::Which/0.05/--force--nodep
  LEOCHARRE::DEBUG/1.14/--force--nodep
  File::chmod/0/--force--nodep
  Linux::usermod/0/--force--nodep
  LEOCHARRE::Class2/0/--force--nodep
  LEOCHARRE::CLI/0/--force--nodep
  String::ShellQuote/0/--force
  LEOCHARRE::CLI2/0/--force--nodep
  Crypt::RC4/2.02/--force--nodep
  Text::PDF/0.29/--force--nodep
  Smart::Comments/0/--force--nodep
  CAM::PDF/1.21/--force--nodep
  PDF::API2/0.69/--force--nodep
  PDF::Burst/1.10/--force--nodep
  PDF::GetImages/1.10/--force--nodep
  Image::OCR::Tesseract/1.10/--force--nodep
  PDF::OCR/1.09/--force--nodep
  PDF::OCR2/1.20/--force--nodep
  });
}

our %postInstallCmd;

if ($^O eq "MSWin32") {
    push (@Modules,'Net::Syslog/0.03');
    push (@Modules,'Win32::Daemon/20030617/--force');
    push (@Modules,'Win32::Unicode/0.28--force');
    push (@Modules,'Win32::DriveInfo/0');
    push (@Modules,'DBD::ADO/2.96');
    push (@Modules,'Win32::API::OutputDebugString/0.03'); 
    unshift (@Modules,'Alien::MSYS/0');
    $postInstallCmd{'Alien::MSYS'} = sub { my $perlbindir = $perlbindir;
                                           $perlbindir =~ s/\/bin$//;
                                           if (-d "$perlbindir/lib/auto/share/dist/Alien-MSYS/msys/1.0/bin") {
                                                copy("$asspdir/assp.mod/msys.uname", "$perlbindir/lib/auto/share/dist/Alien-MSYS/msys/1.0/bin/uname")
                                             && rename("$perlbindir/lib/auto/share/dist/Alien-MSYS/msys/1.0/bin/uname.exe","$perlbindir/lib/auto/share/dist/Alien-MSYS/msys/1.0/bin/uuname.exe")
                                             && print "\n\nenv 'machine' is now set to X86_64 for Alien::MSYS\n\n";} 
                                         } if $is_x86_64;
} else {
    push (@Modules,'Sys::Syslog/0.25');
    push (@Modules,'Filesys::Df/0');
}

# set the download location for some modules away from the CPAN repo
my $defloc = 'https://downloads.sourceforge.net/project/assp/ASSP%20V2%20multithreading/packages/';
our %specialLoc = (
    'Mail::SPF' => $defloc.'Mail-SPF.src.tar.gz',
    'File::Scan::ClamAV'  => $defloc.'File-Scan-ClamAV.src.tar.gz',
    'PDF::Burst'  => $defloc.'PDF-Burst.src.tar.gz',
    'LEOCHARRE::CLI2'  => $defloc.'LEOCHARRE-CLI2.src.tar.gz',
    'Sys::MemInfo' => $defloc.'Sys-MemInfo.src.tar.gz',
    'Crypt::GOST' => $defloc.'Crypt-GOST-1.01.src.tar.gz',
    'Razor2::Client::Agent' => 'https://downloads.sourceforge.net/project/assp/ASSP%20V2%20multithreading/razor2_for_assp/razor-agents.src.tar.gz',
);

if ($forceCPAN && $^O eq "MSWin32") {
    $specialLoc{'Crypt::SMIME'} = $defloc.'Crypt-SMIME-Win32-0.21.tar.gz'
}

print "================================\n";

print "= Installing perl modules      =\n";

print "================================\n";

foreach my $moduleName (@Modules) {
    my ($module,$version,$force) = split (/\//,$moduleName);
    $force = ' ' unless $force;
    $force =~ s/\-\-/ \-\-/g;
    $force =~ s/\-\-nodep/\-\-nofollow/g if($] eq '5.008008');
    my $ver;
    $ver = eval("use $module; $module->VERSION;");
#    print "$@" if $@;
    my $forcePPM = ($^O eq "MSWin32" && $module =~ /LEOCHARRE|Linux::usermod|PDF::|::PDF|Image::OCR|File::chmod/oi);
    my $setcmd = sub {
        if ($^O ne "MSWin32") {
            $cmd = "cpan $module";                             # non windows and Archive::Libarchive::XS cpan
            if (exists $specialLoc{$module}) {
                $cmd = "cpanm -n $specialLoc{$module}";
            }
        } elsif ($module eq 'Archive::Libarchive::XS') {
            next unless eval("use Alien::Libarchive; 1;");     # use ppm for Alien::Libarchive not cpan
            $cmd = "cpan $module";
            $cmd = "cpanm -n $module" if ($forceCPAN);         # use cpan-mini at strawberry
        } else {
            if ($forceCPAN) {
                $cmd = "cpanm -n $module" ;         # windows ppm and cpan
                if (exists $specialLoc{$module}) {
                    $cmd = "cpanm -n $specialLoc{$module}";
                }
            }
            $module =~ s/\:\:/\-/g;
            $module =~ s/Net\-LDAP/Perl\-LDAP/;
            $module =~ s/Mail\-DKIM\-Verifier/Mail\-DKIM/;
            if ($module eq 'MAIL-SPF') {
                $module = "$moddir/$module.ppd";
                $force = ' --force';
            }
            if ($module eq 'NetAddr-IP') {
                $module = "$moddir/$module.ppd";
                $force = ' --force';
            }
            if ($forcePPM) {
                $module = "$moddir/$module.ppd";
            }
            $force = ' ' if $forceCPAN && $forcePPM; # strawberry does not know --force
            $cmd = "ppm install $force $module" if (! $forceCPAN || $forcePPM);
        }
    };
    if ($ver) {
        if ($ver && ($ver lt $version)) {
            print "install/upgrade module $module from version $ver to version $version\n";
            $setcmd->();
            system($cmd);
        } else {
            print "module $module version $ver is already installed\n";
        }
    } else {
        print "install module $module version $version\n";
        $setcmd->();
        system($cmd);
    }
    $postInstallCmd{$module}->() if exists $postInstallCmd{$module};
}

print "\nfinished module installation for ASSP\n\n";

my $haveerror = 0;
print "\nchecking module installation for ASSP\n\n";

sub printout {
    my ($text,$state) = @_;
    my $l = 60 - length $text;
    $l = 0 if $l < 0;
    print $text . ' ' . ('.' x $l) . $state . "\n";
}

foreach my $moduleName (@Modules) {
    my ($module,$version) = split (/\//,$moduleName);
    next if $module eq 'Error'; # this failes here every time
    my $ver;
    $ver = eval("no $module; use $module;$module->VERSION;");
    $ver =~ s/\s+$//o;
    $version =~ s/\s+$//o;
    $ver =~ s/^\s+//o;
    $version =~ s/^\s+//o;
    if ($ver) {
        if ($ver ge $version) {
            printout "module $module $ver",'[OK]';
        } else {
            printout "module $module $ver is installed - $version required",'[upgrade needed]';
            $haveerror = 1 if ($module !~ /thread/i);
        }
        next;
    } else {
        printout "module $module is not installed",'[FAILED]';
        $haveerror = 1;
        next;
    }
}

if ($haveerror && $^O eq "MSWin32" && ! $forceCPAN) {
    print "\n\n errors detected - to correct them do the following:\n\n";
    print "- start cmd.exe\n";
    print "- type >ppm\n";
    print "- if the error was '*** package PACKAGENAME not installed ***'\n";
    print "- type >install PACKAGENAME\n";
    print "- if the error was 'ppm install failed: Can't determine best'\n";
    print "- type >s PACKAGENAME\n";
    print "- look for the line with the highest modules-versionnumber and keep in mind the NUMBER on the left site\n";
    print "- type >install NUMBER   or   >upgrade --install NUMBER\n";
    print "- if you need more help on ppm  type  help\n\n\n";

    print "- or you may use CPAN to install some modules\n";
    print "- for this you'll need to download  ftp://ftp.microsoft.com/softlib/mslfiles/nmake15.exe\n";
    print "- extract nmake15.exe  to your  perl/bin  Directory\n";
    print "- as long, as you have no C-compiler installed on your system, you can only install\n";
    print "- modules that have no XS-code!\n\n";
} elsif ($haveerror) {
    print "\n\n errors detected for some modules \n\n";
} else {
    print "\n\nall modules are installed successful\n\n";
}

if ($^O eq "MSWin32" && ! $forceCPAN) {
    print "\n\nTo update your Perl installation to the latest available state run now :>ppm update --install\n\n";
} else {
    print "\n\nTo update your Perl installation to the latest available state run now :>cpan-outdated -p|cpanm -n\n\n";
    print "On this update you can safely ignore errors reported for modules that contain any of the following strings: LEOCHARRE , Linux::usermod , PDF:: , ::PDF , Image::OCR , File::chmod\n" if $^O eq "MSWin32";
}

exit;

